package exampleFive;

import java.util.Scanner;

public class Rectangle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scanA = new Scanner(System.in);
		System.out.println("Enter the length of the recrangle: ");
		double A = scanA.nextDouble();
		

		Scanner scanB = new Scanner(System.in);
		System.out.println("Enter the width of the rectangle: ");
		double B = scanB.nextDouble();
		
		
		double perimeter = 2*(A + B);
		double area = A * B;
		System.out.println("The area of a rectangle is: " +  area );
		System.out.println("The perimeter of a rectangle is: "+ perimeter );
	}

}
