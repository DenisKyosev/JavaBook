package exampleTen;

import java.util.Scanner;

public class Numbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the numbers: ");
		
		System.out.println("Enter a: ");
		int a = scan.nextInt();
		System.out.println("Enter b: ");
		int b = scan.nextInt();
		System.out.println("Enter c: ");
		int c = scan.nextInt();
		System.out.println("Enter d: ");
		int d = scan.nextInt();
		
		System.out.println("The sum of numbers is : " + a + b + c + d );
		
		System.out.println("\n" + d + c + b + a);

		System.out.println("\n" + d + a + b + c);
		
		System.out.println("\n" + a + c + b + d);

	}

}
