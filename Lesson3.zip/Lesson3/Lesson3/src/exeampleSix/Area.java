package exeampleSix;

import java.util.Scanner;

public class Area {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanA = new Scanner(System.in);
		System.out.println("Enter the length of the recrangle: ");
		double A = scanA.nextDouble();
		
		Scanner scanB = new Scanner(System.in);
		System.out.println("Enter the width of the recrangle: ");
		double B = scanB.nextDouble();
		
		Scanner scanC = new Scanner(System.in);
		System.out.println("Enter the height the recrangle: ");
		double C = scanC.nextDouble();

		double area = (A+B)*C/2;
		System.out.println("The area of the trapez is: " + area);
	}

}
